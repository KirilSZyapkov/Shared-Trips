const router = require('express').Router();
const User = require('../../model/User');

router.get('/profile', async (req, res) => {
    // const isLog = req.user !== undefined;
    // const user = await User.findById(req.user._id).populate('bookdHotels').lean();


    res.render('profile');
})

module.exports = router;