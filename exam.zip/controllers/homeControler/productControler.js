const router = require('express').Router();
const { isGuest, isUser, isOwner } = require('../../middleWares/guards');

const homePage = require('./homePageControler');
const { creatNew, openCreat } = require('./creatTripControler');
const { openDetails, deleteTrip } = require('./detailsTripControler');
const { openEdit, editTrip } = require('./editTripControler');
const bookTrip = require('./bookTripControler');
const sharedTrips = require('./sharedTrips');

router.get('/', homePage);
router.get('/sharedTrips', sharedTrips);
router.get('/createTrip', openCreat);
router.get('/details/:id', openDetails);
router.get('/details/book/:id', bookTrip);
router.get('/details/delete/:id', deleteTrip);
router.get('/details/edit/:id', openEdit)

router.post('/createTrip', creatNew);
router.post('/details/edit/:id', editTrip);

module.exports = router;