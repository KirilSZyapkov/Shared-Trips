const express = require('express');
const app = express();
const mongoose = require("mongoose");

const expressConfig = require('./config/express');
const PORT = require('./config/config');

start();

async function start() {
    return new Promise((resolve, reject) => {

        mongoose.connect('mongodb://localhost:27017/trip', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        const db = mongoose.connection;
        db.on('error', (err) => {
            console.log('Connection error');
            reject();
        });
        db.on('open', () => {
            console.log('Connected to DB');
            resolve();
        })

        expressConfig(app);
    
    
        app.listen(PORT.PORT, () => console.log(`Server is listening on port ${PORT.PORT}...`));
    });

}